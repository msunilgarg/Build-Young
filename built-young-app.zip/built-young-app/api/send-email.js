// Serverless email sender for Built Young.
// Works as a Vercel function at /api/send-email. (For Netlify, see README note.)
//
// Setup:
//   1. Create a Resend account (https://resend.com) and verify your domain (builtyoung.com).
//   2. Add an env var in your host:  RESEND_API_KEY = re_xxxxxxxx
//   3. In src/App.jsx CONFIG, set emailEnabled: true.
//
// This keeps your API key on the server — never in the browser bundle.

export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.status(405).json({ error: "Method not allowed" });
    return;
  }

  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "Email not configured (missing RESEND_API_KEY)" });
    return;
  }

  try {
    const { to, subject, body } = req.body || {};
    if (!to || !subject || !body) {
      res.status(400).json({ error: "Missing to, subject, or body" });
      return;
    }

    // Convert the plain-text body to simple HTML (preserve line breaks).
    const html = `<div style="font-family:Segoe UI,system-ui,sans-serif;font-size:15px;line-height:1.6;color:#242424;white-space:pre-wrap">${
      String(body).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    }</div>`;

    const r = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Built Young <team@builtyoung.com>",
        to: [to],
        subject,
        text: body,
        html,
      }),
    });

    const data = await r.json();
    if (!r.ok) {
      res.status(502).json({ error: "Provider error", detail: data });
      return;
    }
    res.status(200).json({ ok: true, id: data.id });
  } catch (e) {
    res.status(500).json({ error: "Send failed", detail: String(e) });
  }
}
